package com.example.smarthouseiotmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.HandlerThread;
import android.text.InputFilter;
import android.text.Layout;
import android.text.Spanned;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

import com.estimote.coresdk.common.requirements.SystemRequirementsChecker;
import com.estimote.coresdk.observation.region.beacon.BeaconRegion;
import com.estimote.coresdk.recognition.packets.Beacon;
import com.estimote.coresdk.service.BeaconManager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Timer;
import java.util.UUID;

import com.google.firebase.firestore.FirebaseFirestore;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.WorkerThread;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentChange.Type;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FieldPath;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.FirebaseFirestoreSettings;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.MetadataChanges;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.Query.Direction;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.ServerTimestamp;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.firestore.Source;
import com.google.firebase.firestore.Transaction;
import com.google.firebase.firestore.WriteBatch;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.LegendRenderer;
import com.jjoe64.graphview.helper.DateAsXAxisLabelFormatter;
import com.jjoe64.graphview.series.BarGraphSeries;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;


public class MainActivity extends AppCompatActivity implements
        AdapterView.OnItemSelectedListener {

    TextView positionText;
    TextView roomSensors;
    ImageView nearBeaconView;
    ImageView roomView;
    TextView nearBeaconInfo;
    TextView graphTextView;
    TextView graph2TextView;
    Button   lightButton;
    Button   store01Button;
    Button   radiator01Button;
    Button   store02Button;
    Button   radiator02Button;
    Button   statisticsButton;
    Switch autorefreshSwitch;
    ConstraintLayout commandsLayout;
    Boolean  beaconDetected;
    Spinner locationsSpinner;
    ArrayAdapter aa;
    Boolean isPresence=false;
    String currentBeaconRoom="";

    String temperature=null;
    String luminosity=null;
    String presence=null;
    String humidity=null;
    String blind01Value=null;
    String blind02Value=null;
    String valve01Value=null;
    String valve02Value=null;
    String lamp01Value=null;

    Beacon  nearestBeacon;
    static Boolean beaconsReady=false;
    String roomid="";



    int index = 0;
    int index2 = 0;
    private PopupWindow POPUP_WINDOW_SCORE = null;

    ArrayList<String> locations = new ArrayList<String>();

    private FirebaseFirestore db;

    // In the "OnCreate" function below:
    // - TextView, EditText and Button elements are linked to their graphical parts (Done for you ;) )
    // - "OnClick" functions for Increment and Decrement Buttons are implemented (Done for you ;) )
    //
    // TODO List:
    // - Use the Estimote SDK to detect the closest Beacon and figure out the current Room
    //     --> See Estimote documentation:  https://github.com/Estimote/Android-SDK
    // - Set the PositionText with the Room name
    // - Implement the "OnClick" functions for LightButton, StoreButton and RadiatorButton

    private BeaconManager beaconManager;
    private BeaconRegion region;
    private Beacon beacon;

    private static  Map<String, List<String>> PLACES_BY_BEACONS;

    // TODO: replace "<major>:<minor>" strings to match your own beacons.
    static{



    }

    private final int interval = 5000; // 1 Second
    private Handler handler = new Handler();
    private Runnable runnable = new Runnable(){
        public void run() {
            Log.d("NearBeacon", String.format("not present"));
            clearRoom();
            currentBeaconRoom="";
        }
    };


    private List<String> placesNearBeacon(Beacon beacon) {
        String beaconKey = String.format("%s:%s", beacon.getMajor(), beacon.getMinor());
        if (PLACES_BY_BEACONS.containsKey(beaconKey)) {
            return PLACES_BY_BEACONS.get(beaconKey);
        }
        return Collections.emptyList();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        positionText   =  findViewById(R.id.PositionText);
        nearBeaconView = (ImageView)findViewById(R.id.nearBeaconView);
        graphTextView = findViewById(R.id.graphTextView);
        graph2TextView = findViewById(R.id.graph2TextView);
        roomView = (ImageView)findViewById(R.id.roomView);
        nearBeaconInfo   =  findViewById(R.id.nearBeaconInfo);

        lightButton    =  findViewById(R.id.LightButton);
        store01Button    =  findViewById(R.id.store01Button);
        radiator01Button =  findViewById(R.id.radiator01Button);
        store02Button    =  findViewById(R.id.store02Button);
        radiator02Button =  findViewById(R.id.radiator02Button);
        statisticsButton =  findViewById(R.id.statisticsButton);
        commandsLayout = findViewById(R.id.layoutControls);
        roomSensors =  findViewById(R.id.roomSensors);
        locationsSpinner = findViewById(R.id.locationsSpinner);
        autorefreshSwitch = findViewById(R.id.autorefreshSwitch);


        /*lightButton.setEnabled(false);
        store01Button.setEnabled(false);
        store02Button.setEnabled(false);
        radiator01Button.setEnabled(false);
        radiator02Button.setEnabled(false);*/

        locationsSpinner.setOnItemSelectedListener(this);
        aa = new ArrayAdapter(this,android.R.layout.simple_spinner_item,locations);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        //Setting the ArrayAdapter data on the Spinner
        locationsSpinner.setAdapter(aa);
        beaconDetected =false;





        db = FirebaseFirestore.getInstance();


        roomSensors.setText("Presence: False \nTemperature: 22C \nLuminance: 200Lux \nHumidity: 40%");
        nearBeaconInfo.setText("");
        nearBeaconView.setVisibility(View.INVISIBLE);

        getProjectBeacons();

        beaconManager = new BeaconManager(this);
        beaconManager.setForegroundScanPeriod(500, 500);
        region = new BeaconRegion("ranged region",
                UUID.fromString("B9407F30-F5F8-466E-AFF9-25556B57FE6D"), 12423, null);  //major 12423
        //beaconManager.setRegionExitExpiration(1000);
        beaconManager.startRanging(region);

        beaconManager.setRangingListener(new BeaconManager.BeaconRangingListener() {
            @Override
            public void onBeaconsDiscovered(BeaconRegion region, List<Beacon> list) {

                handler.removeCallbacks(runnable);
                handler.postAtTime(runnable, System.currentTimeMillis()+interval);
                handler.postDelayed(runnable, interval);

                if ((!list.isEmpty()) & (beaconsReady)) {
                    Beacon nearestBeacon = list.get(0);


                    double distance = -1;
                    List<String> places = placesNearBeacon(nearestBeacon);
                    currentBeaconRoom = places.get(0);


                    roomid=currentBeaconRoom;
                    Integer loc = locations.indexOf(roomid);
                    if ( !locationsSpinner.getSelectedItem().equals(roomid)){
                        locationsSpinner.setSelection(loc);

                        //getRoomInfo(roomid);
                    }
                    if (autorefreshSwitch.isChecked()){
                        updateRoomInfo(roomid);
                    }


                    /*lightButton.setEnabled(isPresence);
                    store01Button.setEnabled(isPresence);
                    store02Button.setEnabled(isPresence);
                    radiator01Button.setEnabled(isPresence);
                    radiator02Button.setEnabled(isPresence);*/


                    distance = list.get(0).getMeasuredPower() - list.get(0).getRssi();
                    distance = distance / (10 * 3);
                    distance = Math.pow(10, distance);
                    //distance= Math.pow(10, (list.get(0).getMeasuredPower()-list.get(0).getRssi())/(10*2));
                    nearBeaconInfo.setText("Beacon: " + list.get(0).getMinor() +
                            "\nPower: " + String.valueOf(list.get(0).getRssi() +
                            "\nDistance: " + String.format("%.2f", distance)) + "m");

                    if (nearestBeacon.getMinor() == 28809)
                        nearBeaconView.setImageResource(R.mipmap.beacon_rose);
                    if (nearestBeacon.getMinor() == 15713)
                        nearBeaconView.setImageResource(R.mipmap.beacon_blue);
                    nearBeaconView.setVisibility(View.VISIBLE);
                    roomView.setVisibility(View.VISIBLE);
                    commandsLayout.setVisibility((View.VISIBLE));
                    nearBeaconInfo.setVisibility(View.VISIBLE);



                    Log.d("NearBeacon", String.format(places.toString()));

                }
                else{

                    clearRoom();

                }
            }
        });




        store01Button.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                if ((nearBeaconView.getVisibility()!=View.VISIBLE) || (currentBeaconRoom!=roomid))
                    Toast.makeText(getApplicationContext(),"No Beacon detected for this room" , Toast.LENGTH_LONG).show();
                else if (!isPresence)
                    Toast.makeText(getApplicationContext(),"No Presence detected in the room, controlles disabled" , Toast.LENGTH_LONG).show();
                else
                ShowPopup("Store 01 in " + roomid, "kBLIND01", blind01Value,true);


            }
        });



        radiator01Button.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                if ((nearBeaconView.getVisibility()!=View.VISIBLE) || (currentBeaconRoom!=roomid))
                    Toast.makeText(getApplicationContext(),"No Beacon detected for this room" , Toast.LENGTH_LONG).show();
                else if (!isPresence)
                    Toast.makeText(getApplicationContext(),"No Presence detected in the room, controlles disabled" , Toast.LENGTH_LONG).show();
                else
                    ShowPopup("Radiator 01 in " + roomid, "kVALVE01", valve01Value, true);


            }
        });

        store02Button.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                if ((nearBeaconView.getVisibility()!=View.VISIBLE) || (currentBeaconRoom!=roomid))
                    Toast.makeText(getApplicationContext(),"No Beacon detected for this room" , Toast.LENGTH_LONG).show();
                else if (!isPresence)
                    Toast.makeText(getApplicationContext(),"No Presence detected in the room, controlles disabled" , Toast.LENGTH_LONG).show();
                else
                    ShowPopup("Store 02 in " + roomid, "kBLIND02", blind02Value, true);

            }
        });


        radiator02Button.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                if ((nearBeaconView.getVisibility()!=View.VISIBLE) || (currentBeaconRoom!=roomid))
                    Toast.makeText(getApplicationContext(),"No Beacon detected for this room" , Toast.LENGTH_LONG).show();
                else if (!isPresence)
                    Toast.makeText(getApplicationContext(),"No Presence detected in the room, controlles disabled" , Toast.LENGTH_LONG).show();
                else
                    ShowPopup("Radiator 02 in " + roomid, "kVALVE02", valve02Value, true);

            }
        });

        lightButton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                if ((nearBeaconView.getVisibility()!=View.VISIBLE) || (currentBeaconRoom!=roomid))
                    Toast.makeText(getApplicationContext(),"No Beacon detected for this room" , Toast.LENGTH_LONG).show();
                else if (!isPresence)
                    Toast.makeText(getApplicationContext(),"No Presence detected in the room, controlles disabled" , Toast.LENGTH_LONG).show();
                else
                    ShowPopup("Lamp 01 in " + roomid, "zLAMP01", lamp01Value, false);

            }
        });


        statisticsButton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                getRoomStatistics(roomid);
            }
        });

        autorefreshSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                updateRoomInfo(roomid);
            }
        });
    }

    private void ShowPopup(final String message, final String path, final String initValue, final Boolean userOverride)
    {
        DisplayMetrics displayMetrics = this.getResources().getDisplayMetrics();
        int width = displayMetrics.widthPixels;
        int height = displayMetrics.heightPixels;

        // Inflate the popup_layout.xml
        LayoutInflater layoutInflater = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View layout = layoutInflater.inflate(R.layout.command_popup, null);

        // Creating the PopupWindow
        POPUP_WINDOW_SCORE = new PopupWindow(this);
        POPUP_WINDOW_SCORE.setContentView(layout);
        POPUP_WINDOW_SCORE.setWidth(width);
        POPUP_WINDOW_SCORE.setHeight(height);
        POPUP_WINDOW_SCORE.setFocusable(true);

        // prevent clickable background
        POPUP_WINDOW_SCORE.setBackgroundDrawable(null);

        POPUP_WINDOW_SCORE.showAtLocation(layout, Gravity.CENTER, 1, 1);
        final TextView percentage     =  layout.findViewById(R.id.Percentage);
        percentage.setText(initValue);
        TextView txtMessage = (TextView) layout.findViewById(R.id.layout_popup_txtMessage);
        txtMessage.setText(message);

        // Getting a reference to button one and do something
        Button butOne = (Button) layout.findViewById(R.id.layout_popup_butOne);
        butOne.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                String collectionPath = roomid;
                String documentPath = path;
                DocumentReference docRef = db.collection(collectionPath).document(documentPath);

                if (userOverride) {
                    Integer setVal = (int)(Double.parseDouble(percentage.getText().toString())*2.5);
                    docRef.update("SetVal", setVal);
                    documentPath = "0kSETPARAM";

                    docRef = db.collection(collectionPath).document(documentPath);
                    docRef.update("UserOverride", true);

                }else{
                    Integer setVal = (int) (Double.parseDouble(percentage.getText().toString()));
                    docRef.update("SetVal", setVal);


                }
                Toast.makeText(getApplicationContext(),"Value sent" , Toast.LENGTH_LONG).show();


                //Close Window
                POPUP_WINDOW_SCORE.dismiss();
            }
        });

        // Getting a reference to button two and do something
        Button butTwo = (Button) layout.findViewById(R.id.layout_popup_butTwo);
        butTwo.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Toast.makeText(getApplicationContext(),"Cancelled" , Toast.LENGTH_LONG).show();


                //Close Window
                POPUP_WINDOW_SCORE.dismiss();
            }
        });

        // Only accept input values between 0 and 100
        percentage.setFilters(new InputFilter[]{new InputFilterMinMax("0", "100")});
        Button incrButton = (Button) layout.findViewById(R.id.IncrButton);
        incrButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                int number = Integer.parseInt(percentage.getText().toString());
                if (number<100) {
                    number++;
                    Log.d("IoTLab-Inc", String.format("%d",number));
                    percentage.setText(String.format("%d",number));
                }
            }
        });
        Button decrButton = (Button) layout.findViewById(R.id.DecrButton);
        decrButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                int number = Integer.parseInt(percentage.getText().toString());
                if (number>0) {
                    number--;
                    Log.d("IoTLab-Dec", String.format("%d",number));
                    percentage.setText(String.format("%d",number));
                }
            }
        });

    }


    private void clearRoom() {
        nearBeaconView.setVisibility(View.INVISIBLE);
        nearBeaconInfo.setVisibility(View.INVISIBLE);
        roomSensors.setVisibility(View.INVISIBLE);
        roomid="";
        roomView.setVisibility(View.INVISIBLE);
        locationsSpinner.setSelection(0);
        commandsLayout.setVisibility((View.INVISIBLE));
    }

    private void setRoom() {
        //nearBeaconView.setVisibility(View.VISIBLE);
        //nearBeaconInfo.setVisibility(View.VISIBLE);
        roomSensors.setVisibility(View.VISIBLE);
        roomView.setVisibility(View.VISIBLE);
        commandsLayout.setVisibility((View.VISIBLE));
    }
    private void getProjectBeacons() {

        String collectionPath= "BEACONS";

        db.collection(collectionPath)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            String temperature=null;
                            String luminosity=null;
                            String presence=null;
                            String humidity=null;
                            Map<String, Object>  data = new HashMap<>();
                            JSONObject json = null;
                            int x = task.getResult().size();


                            Map<String, List<String>> placesByBeacons = new HashMap<>();

                            locations.add("Waiting for detection..");

                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.d("TAG", document.getId() + " => " + document.getData());

                                data = document.getData();
                                json = new JSONObject(data);
                                JSONObject temp = null;


                                try {
                                    temp = json.getJSONObject("beacon01");
                                    if(temp != null) {
                                        final String beacon_major = temp.getString("major");
                                        final String beacon_minor = temp.getString("minor");
                                        final String beacon_room = temp.getString("room");

                                        placesByBeacons.put(beacon_major + ":" + beacon_minor, new ArrayList<String>() {{
                                            add(beacon_room);
                                        }});
                                        locations.add(beacon_room);



                                    }

                                    temp = json.getJSONObject("beacon02");
                                    if(temp != null) {
                                        final String beacon_major = temp.getString("major");
                                        final String beacon_minor = temp.getString("minor");
                                        final String beacon_room = temp.getString("room");

                                        placesByBeacons.put(beacon_major + ":" + beacon_minor, new ArrayList<String>() {{
                                            add(beacon_room);
                                        }});

                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                            aa.notifyDataSetChanged();


                            PLACES_BY_BEACONS = Collections.unmodifiableMap(placesByBeacons);
                            beaconsReady =true;

                        } else {
                            Log.w("TAG", "Error getting documents.", task.getException());
                        }
                    }
                });








    }
    //Performing action onItemSelected and onNothing selected
    @Override
    public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long id) {
        if (position!=0){
            Log.d("TAG", "Location selected:" + locations.get(position));
            Toast.makeText(getApplicationContext(),locations.get(position) , Toast.LENGTH_LONG).show();
            roomid=locations.get(position);
            updateRoomInfo(roomid);
            setRoom();
        }else{
            clearRoom();
        }


    }
    @Override
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub
    }


    public void getRoomStatistics(String roomid){
        String collectionPath= roomid + "_HISTORY";
        final LineGraphSeries < DataPoint > temperatureSeries = new LineGraphSeries<>();
        final LineGraphSeries < DataPoint > humiditySeries = new LineGraphSeries<>();
        final BarGraphSeries<DataPoint> presenceSeries  = new BarGraphSeries<>();
        final LineGraphSeries < DataPoint > luminositySeries = new LineGraphSeries<>();

        final LineGraphSeries < DataPoint > blind01Series =new LineGraphSeries<>();
        final LineGraphSeries < DataPoint > blind02Series = new LineGraphSeries<>();
        final LineGraphSeries < DataPoint > valve01Series = new LineGraphSeries<>();
        final LineGraphSeries < DataPoint > valve02Series = new LineGraphSeries<>();
        final LineGraphSeries < DataPoint > lamp01Series = new LineGraphSeries<>();

        final LineGraphSeries<DataPoint> finalTemperatureSeries = temperatureSeries;
        db.collection(collectionPath)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {


                            Map<String, Object>  data = new HashMap<>();
                            JSONObject json = null;
                            int x = task.getResult().size();
                            int valPresence;
                            index=0;
                            index2=0;
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.d("TAG", document.getId() + " => " + document.getData());

                                data = document.getData();
                                json = new JSONObject(data);


                                String documentName=document.getId();


                                try {
                                    if (documentName.charAt(documentName.length()-1) =='z') {
                                        JSONObject temp = json.getJSONObject("SENSOR01");
                                        if(temp != null) {
                                            temperature = temp.getString("Temperature");
                                            luminosity = temp.getString("Luminosity");
                                            presence = temp.getString("Presence");
                                            humidity = temp.getString("Humidity");
                                            temperatureSeries.appendData(new DataPoint(index, Double.parseDouble(temperature)),false,1000);
                                            humiditySeries.appendData(new DataPoint(index, Double.parseDouble(humidity)),false,1000);
                                            luminositySeries.appendData(new DataPoint(index, Double.parseDouble(luminosity)),false,1000);
                                            if (presence=="true") valPresence=5;
                                            else valPresence=0;
                                            presenceSeries.appendData(new DataPoint(index, valPresence),false,1000);
                                            index+=1;
                                        }
                                        temp = json.getJSONObject("LAMP01");
                                        if(temp != null) {
                                            lamp01Value = temp.getString("real_val");
                                        }

                                    }else if (documentName.charAt(documentName.length()-1) =='k') {
                                        JSONObject temp = json.getJSONObject("BLIND01");
                                        if(temp != null) {
                                            blind01Value = temp.getString("real_val");
                                            blind01Series.appendData(new DataPoint(index2, Double.parseDouble(blind01Value)*0.4),false,1000);
                                        }
                                        temp = json.getJSONObject("BLIND02");
                                        if(temp != null) {
                                            blind02Value = temp.getString("real_val");
                                            blind02Series.appendData(new DataPoint(index2, Double.parseDouble(blind02Value)*0.4),false,1000);
                                        }
                                        temp = json.getJSONObject("VALVE01");
                                        if(temp != null) {
                                            valve01Value = temp.getString("real_val");
                                            valve01Series.appendData(new DataPoint(index2, Double.parseDouble(valve01Value)*0.4),false,1000);
                                        }
                                        temp = json.getJSONObject("VALVE02");
                                        if(temp != null) {
                                            valve02Value = temp.getString("real_val");
                                            valve02Series.appendData(new DataPoint(index2, Double.parseDouble(valve02Value)*0.4),false,1000);
                                        }
                                        lamp01Series.appendData(new DataPoint(index2, Double.parseDouble(lamp01Value)),false,1000);
                                        index2+=1;
                                    }

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }


                            }
                            final GraphView graph = (GraphView) findViewById(R.id.graph);
                            graph.setVisibility(View.VISIBLE);


                            finalTemperatureSeries.setColor(Color.BLUE);
                            humiditySeries.setColor(Color.RED);
                            luminositySeries.setColor(Color.YELLOW);
                            presenceSeries.setColor(Color.GREEN);

                            // legend
                            finalTemperatureSeries.setTitle("Temperature");
                            humiditySeries.setTitle("Humidity");
                            luminositySeries.setTitle("Luminosity");
                            presenceSeries.setTitle("Presence");

                            graph.getLegendRenderer().setVisible(true);
                            graph.getLegendRenderer().setFixedPosition(0, 0);
                            graph.getLegendRenderer().setVisible(true);
                            graph.removeAllSeries();

                            // set manual X bounds
                            graph.getViewport().setYAxisBoundsManual(true);
                            graph.getViewport().setMinY(-5);
                            graph.getViewport().setMaxY(40);
                            graph.getViewport().setXAxisBoundsManual(true);
                            graph.getViewport().setMinX(0);
                            graph.getViewport().setMaxX(index);

                            // enable scaling and scrolling
                            graph.getViewport().setScalable(true);
                            graph.getViewport().setScalableY(true);

                            graph.addSeries(finalTemperatureSeries);
                            graph.addSeries(humiditySeries);
                            graph.addSeries(luminositySeries);
                            graph.addSeries(presenceSeries);

                            graph.getGridLabelRenderer().setNumHorizontalLabels(10);
                            graph.getGridLabelRenderer().setNumVerticalLabels(10);


                            graphTextView.setText("\n\nStatistics:" +
                                    "\n\nTemp_max: " + finalTemperatureSeries.getHighestValueY() + " C" +
                                    "\nHum_max: " + humiditySeries.getHighestValueY() + " %" +
                                    "\nLum_max: " + luminositySeries.getHighestValueY() + " Lux");


                            final GraphView graph2 = (GraphView) findViewById(R.id.graph2);
                            graph2.setVisibility(View.VISIBLE);

                            blind01Series.setColor(Color.CYAN);
                            blind02Series.setColor(Color.MAGENTA);
                            valve01Series.setColor(Color.GRAY);
                            valve02Series.setColor(Color.BLACK);
                            lamp01Series.setColor(Color.YELLOW);

                            blind01Series.setTitle("Blind 01");
                            blind02Series.setTitle("Blind 02");
                            valve01Series.setTitle("Radiator 01");
                            valve02Series.setTitle("Radiator 02");
                            lamp01Series.setTitle("Lamp 01");

                            graph2.getLegendRenderer().setVisible(true);
                            graph2.getLegendRenderer().setFixedPosition(0, 0);
                            graph2.getLegendRenderer().setVisible(true);
                            graph2.removeAllSeries();

                            // set manual X bounds
                            graph2.getViewport().setYAxisBoundsManual(true);
                            graph2.getViewport().setMinY(0);
                            graph2.getViewport().setMaxY(105);
                            graph2.getViewport().setXAxisBoundsManual(true);
                            graph2.getViewport().setMinX(0);
                            graph2.getViewport().setMaxX(index2);

                            // enable scaling and scrolling
                            graph2.getViewport().setScalable(true);
                            graph2.getViewport().setScalableY(true);

                            graph2.addSeries(blind01Series);
                            graph2.addSeries(blind02Series);
                            graph2.addSeries(valve01Series);
                            graph2.addSeries(valve02Series);
                            graph2.addSeries(lamp01Series);

                            graph2.getGridLabelRenderer().setNumHorizontalLabels(10);
                            graph2.getGridLabelRenderer().setNumVerticalLabels(10);

                           /* graph2TextView.setText("\n\nStatistics:" +
                                    "\n\nTemp_max: " + temperatureSeries.getHighestValueY() + " C" +
                                    "\nHum_max: " + humiditySeries.getHighestValueY() + " %" +
                                    "\nLum_max: " + luminositySeries.getHighestValueY() + " Lux");*/

                        } else {
                            Log.w("TAG", "Error getting documents.", task.getException());
                        }
                    }
                });



    }



    public void updateRoomInfo(String roomid){
        String collectionPath= roomid;

        db.collection(collectionPath)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {

                            Map<String, Object>  data = new HashMap<>();
                            JSONObject json = null;
                            int x = task.getResult().size();

                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.d("TAG", document.getId() + " => " + document.getData());

                                data = document.getData();
                                json = new JSONObject(data);


                                String documentName=document.getId();

                                try {
                                    if(json != null) {
                                        if (documentName.equals("kBLIND01")) {
                                            blind01Value = json.getString("RealVal");
                                            blind01Value=Integer.toString((int)((Double.parseDouble(blind01Value)*0.4)));
                                        }
                                        if (documentName.equals("kBLIND02")) {
                                            blind02Value = json.getString("RealVal");
                                            blind02Value=Integer.toString((int)((Double.parseDouble(blind02Value)*0.4)));
                                        }
                                        if (documentName.equals("kVALVE01")) {
                                            valve01Value = json.getString("RealVal");
                                            valve01Value=Integer.toString((int)((Double.parseDouble(valve01Value)*0.4)));
                                        }
                                        if (documentName.equals("kVALVE02")) {
                                            valve02Value = json.getString("RealVal");
                                            valve02Value=Integer.toString((int)((Double.parseDouble(valve02Value)*0.4)));
                                        }
                                        if (documentName.equals("zLAMP01")) {
                                            lamp01Value = json.getString("RealVal");
                                            lamp01Value=Integer.toString((int)((Double.parseDouble(lamp01Value))));
                                        }
                                        if (documentName.equals("zSENSOR01")) {
                                            temperature = json.getString("Temperature");
                                            luminosity = json.getString("Luminosity");
                                            presence = json.getString("Presence");
                                            humidity = json.getString("Humidity");
                                        }





                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }


                            }

                            roomSensors.setText("Presence:\t\t\t " + presence +
                                    "\nTemperature:\t " + temperature + " C" +
                                    "\nLuminance:\t\t " + luminosity + " Lux" + "" +
                                    "\nHumidity:\t\t\t\t " + humidity + " % " /*+
                                    "\n\nStore 01:\t\t " + blind01Value +" % " +
                                    "\nStore 02:\t\t " + blind02Value + " % " +
                                    "\nRadiator 01:\t " + valve01Value + " % " +
                                    "\nRadiator 02:\t " + valve02Value + " % " +
                                    "\nLamp 01:\t " + lamp01Value + " % "*/);

                            isPresence=(presence=="true");
                            store01Button.setText("Blind01\n"+ blind01Value +"%");
                            store02Button.setText("Blind02\n"+ blind02Value +"%");
                            radiator01Button.setText("Rad01\n"+ valve01Value +"%");
                            radiator02Button.setText("Rad02\n"+ valve02Value +"%");
                            lightButton.setText("Lamp01\n"+ lamp01Value +"%");

                        } else {
                            Log.w("TAG", "Error getting documents.", task.getException());
                        }
                    }
                });




    }




    // You will be using "OnResume" and "OnPause" functions to resume and pause Beacons ranging (scanning)
    // See estimote documentation:  https://developer.estimote.com/android/tutorial/part-3-ranging-beacons/
    @Override
    protected void onResume() {
        super.onResume();

        SystemRequirementsChecker.checkWithDefaultDialogs(this);

        beaconManager.connect(new BeaconManager.ServiceReadyCallback() {
            @Override
            public void onServiceReady() {
                region = new BeaconRegion("ranged region",
                        UUID.fromString("B9407F30-F5F8-466E-AFF9-25556B57FE6D"), 12423, null);
                beaconManager.startRanging(region);
            }
        });

    }


    @Override
    protected void onPause() {
        beaconManager.stopRanging(region);

        super.onPause();

    }

}


// This class is used to filter input, you won't be using it.

class InputFilterMinMax implements InputFilter {
    private int min, max;

    public InputFilterMinMax(int min, int max) {
        this.min = min;
        this.max = max;
    }

    public InputFilterMinMax(String min, String max) {
        this.min = Integer.parseInt(min);
        this.max = Integer.parseInt(max);
    }

    @Override
    public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
        try {
            int input = Integer.parseInt(dest.toString() + source.toString());
            if (isInRange(min, max, input))
                return null;
        } catch (NumberFormatException nfe) { }
        return "";
    }

    private boolean isInRange(int a, int b, int c) {
        return b > a ? c >= a && c <= b : c >= b && c <= a;
    }
}













